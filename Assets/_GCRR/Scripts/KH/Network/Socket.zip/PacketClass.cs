using JetBrains.Annotations;
using System;
using System.Collections.Generic;
using static UnityEngine.Rendering.DebugUI;

[Serializable]
public class PacketData
{
    public ushort packetSize;
    public PacketID packetID;
    public byte[] dataBytes;

    public static PacketData DeSerialization(byte[] bytes)
    {
        int parsCnt = 0;
        PacketData packetData = new PacketData();

        packetData.packetSize = UTILS.BytesToUShort(bytes, ref parsCnt);

        packetData.packetID = (PacketID)UTILS.BytesToUShort(bytes, ref parsCnt);

        byte[] result = new byte[packetData.packetSize];
        Array.Copy(bytes, parsCnt, result, 0, packetData.packetSize);
        packetData.dataBytes = result;

        return packetData;
    }

}

[Serializable]
public class S_MyPlayerID
{
    public PacketID packetID = PacketID.S_MyPlayerID;
    public int playerID;

    public S_MyPlayerID() { }

    public S_MyPlayerID(int _playerID)
    {
        Init(_playerID);
    }

    public void Init(int _playerID)
    {
        this.playerID = _playerID;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);

        ushort len = (ushort)(playerIDBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);

        return result;
    }

    public static S_MyPlayerID DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        S_MyPlayerID myPlayerID = new S_MyPlayerID();
        if (packetData.packetID != PacketID.S_MyPlayerID) return null;

        #region playerID
        myPlayerID.playerID = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        return myPlayerID;
    }
}

[Serializable]
public class C_ChangeObjInfo
{
    public PacketID packetID = PacketID.C_ChangeObjInfo;
    public int playerID;
    public ScenarioObjectInteractionType interactionType;     // ��ȣ�ۿ� ����
    public int objSequence;      // ������Ʈ ����
    public ObjectData objectData = new ObjectData();

    public C_ChangeObjInfo() { }

    public C_ChangeObjInfo(int _playerID, ScenarioObjectInteractionType _interactionType, int _objSequence, ObjectData _objectData)
    {
        Init(_playerID, _interactionType, _objSequence, _objectData);
    }

    public void Init(int _playerID, ScenarioObjectInteractionType _interactionType, int _objSequence, ObjectData _objectData)
    {
        this.playerID = _playerID;
        this.interactionType = _interactionType;
        this.objSequence = _objSequence;
        this.objectData = _objectData;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);
        byte[] interactionBytes = BitConverter.GetBytes((int)interactionType);
        byte[] objSequenceBytes = BitConverter.GetBytes(objSequence);

        byte[] objectIDBytes = BitConverter.GetBytes(objectData.GetObjectID());
        byte[] forceSizeBytes = BitConverter.GetBytes(objectData.GetForceSize());
        byte[] forceCodeBytes = UTILS.StringToBytes(objectData.GetForceCode());
        byte[] unitNameBytes = UTILS.StringToBytes(objectData.GetUnitName());
        byte[] unitCodeBytes = UTILS.StringToBytes(objectData.GetUnitCode());
        byte[] allyBytes = BitConverter.GetBytes(objectData.GetIsAlly());
        byte[] latBytes = BitConverter.GetBytes(objectData.GetUnitLat());
        byte[] lonBytes = BitConverter.GetBytes(objectData.GetUnitLon());
        byte[] heightBytes = BitConverter.GetBytes(objectData.GetUnitHeight());
        byte[] showForceMarkBytes = BitConverter.GetBytes(objectData.GetShowForceMark());
        byte[] missionBytes = UTILS.StringToBytes(objectData.GetUnitMission());
        byte[] movingDirectionbBytes = BitConverter.GetBytes(objectData.GetMovingDirection());

        ushort len = (ushort)(playerIDBytes.Length + interactionBytes.Length + objSequenceBytes.Length
                                + objectIDBytes.Length + forceSizeBytes.Length + forceCodeBytes.Length
                                + unitNameBytes.Length + unitCodeBytes.Length + allyBytes.Length
                                + latBytes.Length + lonBytes.Length + heightBytes.Length
                                + showForceMarkBytes.Length + missionBytes.Length + movingDirectionbBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);
        result = UTILS.AddBytes(result, interactionBytes);
        result = UTILS.AddBytes(result, objSequenceBytes);
        result = UTILS.AddBytes(result, objectIDBytes);
        result = UTILS.AddBytes(result, forceSizeBytes);
        result = UTILS.AddBytes(result, forceCodeBytes);
        result = UTILS.AddBytes(result, unitNameBytes);
        result = UTILS.AddBytes(result, unitCodeBytes);
        result = UTILS.AddBytes(result, allyBytes);
        result = UTILS.AddBytes(result, latBytes);
        result = UTILS.AddBytes(result, lonBytes);
        result = UTILS.AddBytes(result, heightBytes);
        result = UTILS.AddBytes(result, showForceMarkBytes);
        result = UTILS.AddBytes(result, missionBytes);
        result = UTILS.AddBytes(result, movingDirectionbBytes);

        return result;
    }

    public static C_ChangeObjInfo DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        int stringLen = 0;

        byte[] bytes = packetData.dataBytes;

        C_ChangeObjInfo c_ChangeObjInfo = new C_ChangeObjInfo();
        if (packetData.packetID != PacketID.C_ChangeObjInfo) return null;

        #region playerID
        c_ChangeObjInfo.playerID = UTILS.BytesToInt(bytes, ref parsCnt);
        #endregion

        #region Interaction
        c_ChangeObjInfo.interactionType = (ScenarioObjectInteractionType)UTILS.BytesToInt(bytes, ref parsCnt);
        #endregion

        #region ObjSequence
        c_ChangeObjInfo.objSequence = UTILS.BytesToInt(bytes, ref parsCnt);
        #endregion

        #region objectID
        c_ChangeObjInfo.objectData.SetObjectID(UTILS.BytesToInt(bytes, ref parsCnt));
        #endregion

        #region forceSize
        c_ChangeObjInfo.objectData.SetForceSize(UTILS.BytesToInt(bytes, ref parsCnt));
        #endregion

        #region forceCode
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        c_ChangeObjInfo.objectData.SetForceCode(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        # region unitName
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        c_ChangeObjInfo.objectData.SetUnitName(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        #region unitCode
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        c_ChangeObjInfo.objectData.SetUnitCode(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        #region isAlly
        c_ChangeObjInfo.objectData.SetIsAlly(UTILS.BytesToBoolean(bytes, ref parsCnt));
        #endregion

        #region lat    
        c_ChangeObjInfo.objectData.SetUnitLat(UTILS.BytesToFloat(bytes, ref parsCnt));
        #endregion

        #region lon
        c_ChangeObjInfo.objectData.SetUnitLon(UTILS.BytesToFloat(bytes, ref parsCnt));
        #endregion

        #region height
        c_ChangeObjInfo.objectData.SetUnitHeiget(UTILS.BytesToFloat(bytes, ref parsCnt));
        #endregion

        #region showForceMark
        c_ChangeObjInfo.objectData.SetShowForceMark(UTILS.BytesToBoolean(bytes, ref parsCnt));
        #endregion

        #region mission
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        c_ChangeObjInfo.objectData.SetUnitMission(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        #region movingdirection
        c_ChangeObjInfo.objectData.SetMovingDirection(UTILS.BytesToInt(bytes, ref parsCnt));
        #endregion

        return c_ChangeObjInfo;
    }
}

[Serializable]
public class S_ChangeObjInfo
{
    public PacketID packetID = PacketID.S_ChangeObjInfo;
    public int playerID;
    public ScenarioObjectInteractionType interactionType;     // ��ȣ�ۿ� ����
    public int objSequence;      // ������Ʈ ����
    public ObjectData objectData = new ObjectData();

    public S_ChangeObjInfo() { }

    public S_ChangeObjInfo(int _playerID, ScenarioObjectInteractionType _interactionType, int _objSequence, ObjectData _objectData)
    {
        Init(_playerID, _interactionType, _objSequence, _objectData);
    }

    public void Init(int _playerID, ScenarioObjectInteractionType _interactionType, int _objSequence, ObjectData _objectData)
    {
        this.playerID = _playerID;
        this.interactionType = _interactionType;
        this.objSequence = _objSequence;
        this.objectData = _objectData;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);
        byte[] interactionBytes = BitConverter.GetBytes((int)interactionType);
        byte[] objSequenceBytes = BitConverter.GetBytes(objSequence);

        byte[] objectIDBytes = BitConverter.GetBytes(objectData.GetObjectID());
        byte[] forceSizeBytes = BitConverter.GetBytes(objectData.GetForceSize());
        byte[] forceCodeBytes = UTILS.StringToBytes(objectData.GetForceCode());
        byte[] unitNameBytes = UTILS.StringToBytes(objectData.GetUnitName());
        byte[] unitCodeBytes = UTILS.StringToBytes(objectData.GetUnitCode());
        byte[] allyBytes = BitConverter.GetBytes(objectData.GetIsAlly());
        byte[] latBytes = BitConverter.GetBytes(objectData.GetUnitLat());
        byte[] lonBytes = BitConverter.GetBytes(objectData.GetUnitLon());
        byte[] heightBytes = BitConverter.GetBytes(objectData.GetUnitHeight());
        byte[] showForceMarkBytes = BitConverter.GetBytes(objectData.GetShowForceMark());
        byte[] missionBytes = UTILS.StringToBytes(objectData.GetUnitMission());
        byte[] movingDirectionbBytes = BitConverter.GetBytes(objectData.GetMovingDirection());

        ushort len = (ushort)(playerIDBytes.Length + interactionBytes.Length + objSequenceBytes.Length
                                + objectIDBytes.Length + forceSizeBytes.Length + forceCodeBytes.Length
                                + unitNameBytes.Length + unitCodeBytes.Length + allyBytes.Length
                                + latBytes.Length + lonBytes.Length + heightBytes.Length
                                + showForceMarkBytes.Length + missionBytes.Length + movingDirectionbBytes.Length);

        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);
        result = UTILS.AddBytes(result, interactionBytes);
        result = UTILS.AddBytes(result, objSequenceBytes);
        result = UTILS.AddBytes(result, objectIDBytes);
        result = UTILS.AddBytes(result, forceSizeBytes);
        result = UTILS.AddBytes(result, forceCodeBytes);
        result = UTILS.AddBytes(result, unitNameBytes);
        result = UTILS.AddBytes(result, unitCodeBytes);
        result = UTILS.AddBytes(result, allyBytes);
        result = UTILS.AddBytes(result, latBytes);
        result = UTILS.AddBytes(result, lonBytes);
        result = UTILS.AddBytes(result, heightBytes);
        result = UTILS.AddBytes(result, showForceMarkBytes);
        result = UTILS.AddBytes(result, missionBytes);
        result = UTILS.AddBytes(result, movingDirectionbBytes);

        return result;
    }

    public static S_ChangeObjInfo DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        int stringLen = 0;

        byte[] bytes = packetData.dataBytes;

        S_ChangeObjInfo s_ChangeObjInfo = new S_ChangeObjInfo();
        if (packetData.packetID != PacketID.S_ChangeObjInfo) return null;

        #region playerID
        s_ChangeObjInfo.playerID = UTILS.BytesToInt(bytes, ref parsCnt);
        #endregion

        #region Interaction
        s_ChangeObjInfo.interactionType = (ScenarioObjectInteractionType)UTILS.BytesToInt(bytes, ref parsCnt);
        #endregion

        #region ObjSequence
        s_ChangeObjInfo.objSequence = UTILS.BytesToInt(bytes, ref parsCnt);
        #endregion

        #region objectID
        s_ChangeObjInfo.objectData.SetObjectID(UTILS.BytesToInt(bytes, ref parsCnt));
        #endregion

        #region forceSize
        s_ChangeObjInfo.objectData.SetForceSize(UTILS.BytesToInt(bytes, ref parsCnt));
        #endregion

        #region forceCode
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        s_ChangeObjInfo.objectData.SetForceCode(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        # region unitName
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        s_ChangeObjInfo.objectData.SetUnitName(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        #region unitCode
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        s_ChangeObjInfo.objectData.SetUnitCode(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        #region isAlly
        s_ChangeObjInfo.objectData.SetIsAlly(UTILS.BytesToBoolean(bytes, ref parsCnt));
        #endregion

        #region lat    
        s_ChangeObjInfo.objectData.SetUnitLat(UTILS.BytesToFloat(bytes, ref parsCnt));
        #endregion

        #region lon
        s_ChangeObjInfo.objectData.SetUnitLon(UTILS.BytesToFloat(bytes, ref parsCnt));
        #endregion

        #region height
        s_ChangeObjInfo.objectData.SetUnitHeiget(UTILS.BytesToFloat(bytes, ref parsCnt));
        #endregion

        #region showForceMark
        s_ChangeObjInfo.objectData.SetShowForceMark(UTILS.BytesToBoolean(bytes, ref parsCnt));
        #endregion

        #region mission
        stringLen = UTILS.BytesToUShort(bytes, ref parsCnt);

        s_ChangeObjInfo.objectData.SetUnitMission(UTILS.BytesToString(bytes, stringLen, ref parsCnt));
        #endregion

        #region movingdirection
        s_ChangeObjInfo.objectData.SetMovingDirection(UTILS.BytesToInt(bytes, ref parsCnt));
        #endregion

        return s_ChangeObjInfo;
    }
}

[Serializable]
public class C_SaveScenario
{
    public PacketID packetID = PacketID.C_SaveScenario;
    public int playerID;
    public string scenarioID;
    public string scenarioName;
    public string folderName;
    public float lat;
    public float lon;
    public string writer;
    public string mapType;
    public int scale;
    public int range;
    public string description;
    public string writeDay;

    public C_SaveScenario() { }

    public C_SaveScenario(int _playerID, string _scenarioID, string _scenarioName, string _folderName,
        float _lat, float _lon, string _writer, string _mapType, int _scale, int _range, string _description, string _writeDay)
    {
        Init(_playerID, _scenarioID, _scenarioName, _folderName, _lat, _lon, _writer, _mapType, _scale, _range, _description, _writeDay);
    }

    public void Init(int _playerID, string _scenarioID, string _scenarioName, string _folderName,
        float _lat, float _lon, string _writer, string _mapType, int _scale, int _range, string _description, string _writeDay)
    {
        this.playerID = _playerID;
        this.scenarioID = _scenarioID;
        this.scenarioName = _scenarioName;
        this.folderName = _folderName;
        this.lat = _lat;
        this.lon = _lon;
        this.writer = _writer;
        this.mapType = _mapType;
        this.scale = _scale;
        this.range = _range;
        this.description = _description;
        this.writeDay = _writeDay;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);
        byte[] scenarioIDBytes = UTILS.StringToBytes(scenarioID);
        byte[] scenarioNameBytes = UTILS.StringToBytes(scenarioName);
        byte[] folderNameBytes = UTILS.StringToBytes(folderName);
        byte[] latBytes = BitConverter.GetBytes(lat);
        byte[] lonBytes = BitConverter.GetBytes(lon);
        byte[] writerBytes = UTILS.StringToBytes(writer);
        byte[] mapTypeBytes = UTILS.StringToBytes(mapType);
        byte[] scaleBytes = BitConverter.GetBytes(scale);
        byte[] rangeBytes = BitConverter.GetBytes(range);
        byte[] descriptionBytes = UTILS.StringToBytes(description);
        byte[] writeDayBytes = UTILS.StringToBytes(writeDay);

        ushort len = (ushort)(playerIDBytes.Length + scenarioIDBytes.Length + scenarioNameBytes.Length
                                + folderNameBytes.Length + latBytes.Length + lonBytes.Length
                                + writerBytes.Length + mapTypeBytes.Length + scaleBytes.Length
                                + rangeBytes.Length + descriptionBytes.Length + writeDayBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);
        result = UTILS.AddBytes(result, scenarioIDBytes);
        result = UTILS.AddBytes(result, scenarioNameBytes);
        result = UTILS.AddBytes(result, folderNameBytes);
        result = UTILS.AddBytes(result, latBytes);
        result = UTILS.AddBytes(result, lonBytes);
        result = UTILS.AddBytes(result, writerBytes);
        result = UTILS.AddBytes(result, mapTypeBytes);
        result = UTILS.AddBytes(result, scaleBytes);
        result = UTILS.AddBytes(result, rangeBytes);
        result = UTILS.AddBytes(result, descriptionBytes);
        result = UTILS.AddBytes(result, writeDayBytes);

        return result;
    }

    public static C_SaveScenario DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        int stringLen = 0;

        C_SaveScenario c_SaveScenario = new C_SaveScenario();
        if (packetData.packetID != PacketID.C_SaveScenario) return null;

        #region playerID
        c_SaveScenario.playerID = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        #region ScenarioID
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.scenarioID = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        #region ScenarioName
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.scenarioName = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        #region FolderName
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.folderName = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        #region Lat
        c_SaveScenario.lat = UTILS.BytesToFloat(packetData.dataBytes, ref parsCnt);
        #endregion

        #region Lon
        c_SaveScenario.lat = UTILS.BytesToFloat(packetData.dataBytes, ref parsCnt);
        #endregion

        #region Writer
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.writer = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        #region MapType
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.mapType = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        #region Scale
        c_SaveScenario.scale = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        #region Range
        c_SaveScenario.range = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        #region Description
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.description = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        #region WriteDay
        stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        c_SaveScenario.description = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        return c_SaveScenario;
    }
}

[Serializable]
public class S_SaveScenarioResult
{
    public PacketID packetID = PacketID.S_SaveScenarioResult;
    public int playerID;
    public bool saveResult;

    public S_SaveScenarioResult() { }

    public S_SaveScenarioResult(int _playerID, bool _saveResult)
    {
        Init(_playerID, _saveResult);
    }

    public void Init(int _playerID, bool _saveResult)
    {
        this.playerID = _playerID;
        this.saveResult = _saveResult;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);
        byte[] saveResultBytes = BitConverter.GetBytes(saveResult);

        ushort len = (ushort)(playerIDBytes.Length + saveResultBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);
        result = UTILS.AddBytes(result, saveResultBytes);

        return result;
    }


    public static S_SaveScenarioResult DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;

        S_SaveScenarioResult s_SaveScenarioResult = new S_SaveScenarioResult();
        if (packetData.packetID != PacketID.S_SaveScenarioResult) return null;

        #region playerID
        s_SaveScenarioResult.playerID = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        #region SaveResult
        s_SaveScenarioResult.saveResult = UTILS.BytesToBoolean(packetData.dataBytes, ref parsCnt);
        #endregion

        return s_SaveScenarioResult;
    }
}

[Serializable]
public class C_LeaveGame
{
    public PacketID packetID = PacketID.C_LeaveGame;
    public int playerID;

    public C_LeaveGame() { }

    public C_LeaveGame(int _playerID)
    {
        Init(_playerID);
    }

    public void Init(int _playerID)
    {
        this.playerID = _playerID;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);

        ushort len = (ushort)(playerIDBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);

        return result;
    }

    public static C_LeaveGame DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;

        C_LeaveGame c_LeaveGame = new C_LeaveGame();
        if (packetData.packetID != PacketID.C_LeaveGame) return null;

        #region playerID
        c_LeaveGame.playerID = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        return c_LeaveGame;
    }
}

[Serializable]
public class S_BroadcastNewOwner
{
    public PacketID packetID = PacketID.S_BroadcastNewOwner;
    public int playerID;

    public S_BroadcastNewOwner() { }

    public S_BroadcastNewOwner(int _playerID)
    {
        Init(_playerID);
    }

    public void Init(int _playerID)
    {
        this.playerID = _playerID;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] playerIDBytes = BitConverter.GetBytes(playerID);

        ushort len = (ushort)(playerIDBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, playerIDBytes);

        return result;
    }

    public static S_BroadcastNewOwner DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;

        S_BroadcastNewOwner s_BroadcastNewOwner = new S_BroadcastNewOwner();
        if (packetData.packetID != PacketID.S_BroadcastNewOwner) return null;

        #region playerID
        s_BroadcastNewOwner.playerID = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        return s_BroadcastNewOwner;
    }

}

public class Response_ScenarioList
{
    public PacketID packetID = PacketID.Response_ScenrioList;
    public ScenarioList scenarioList = new ScenarioList();

    public Response_ScenarioList() { }

    public Response_ScenarioList(ScenarioList _scenarioList)
    {
        Init(scenarioList = _scenarioList);
    }

    public void Init(ScenarioList _scenarioList)
    {
        scenarioList = _scenarioList;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);

        byte[] listBytes = scenarioList.Serialization();

        ushort len = (ushort)listBytes.Length;
        byte[] lengthBytes = BitConverter.GetBytes(len);
        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, listBytes);

        return result;
    }

    public static Response_ScenarioList DeSerialization(PacketData packetData)
    {
        Response_ScenarioList response_ScenarioLists = new Response_ScenarioList();
        if (packetData.packetID != PacketID.Response_ScenrioList) return null;

        response_ScenarioLists.scenarioList = ScenarioList.DeSerialization(packetData.dataBytes);

        return response_ScenarioLists;
    }
}

[Serializable]
public class Request_ScenarioList
{
    public PacketID packetID = PacketID.Request_ScenarioList;

    public Request_ScenarioList() { }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);

        ushort len = 0;
        byte[] lengthBytes = BitConverter.GetBytes(len);
        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);

        return result;
    }

    public static Request_ScenarioList DeSerialization(PacketData packetData)
    {
        Request_ScenarioList request_ScenarioLists = new Request_ScenarioList();
        if (packetData.packetID != PacketID.Request_ScenarioList) return null;

        return request_ScenarioLists;
    }
}

[Serializable]
public class Response_ScenarioData
{
    public PacketID packetID = PacketID.Response_ScenrioData;
    public ScenarioData scenarioData;

    public Response_ScenarioData() { }

    public Response_ScenarioData(ScenarioData _scenarioData)
    {
        Init(_scenarioData);
    }

    public void Init(ScenarioData _scenarioData)
    {
        this.scenarioData = _scenarioData;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] scenarioDataBytes = scenarioData.Serialization();

        ushort len = (ushort)(scenarioDataBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, scenarioDataBytes);

        return result;
    }

    public static Response_ScenarioData DeSerialization(PacketData packetData)
    {
        Response_ScenarioData response_ScenarioData = new Response_ScenarioData();
        if (packetData.packetID != PacketID.Response_ScenrioData) return null;

        #region ScenarioData
        response_ScenarioData.scenarioData = ScenarioData.DeSerialization(packetData.dataBytes);
        #endregion

        return response_ScenarioData;
    }
}

[Serializable]
public class Request_ScenarioData
{
    public PacketID packetID = PacketID.Request_ScenarioData;
    public string scenarioName;

    public Request_ScenarioData() { }

    public Request_ScenarioData(string _scenarioName)
    {
        Init(_scenarioName);
    }

    public void Init(string _scenarioName)
    {
        this.scenarioName = _scenarioName;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] scenarioNameBytes = UTILS.StringToBytes(scenarioName);

        ushort len = (ushort)(scenarioNameBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, scenarioNameBytes);

        return result;
    }

    public static Request_ScenarioData DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        Request_ScenarioData request_ScenarioData = new Request_ScenarioData();
        if (packetData.packetID != PacketID.Request_ScenarioData) return null;

        #region ScenarioName
        int stringLen = UTILS.BytesToUShort(packetData.dataBytes, ref parsCnt);

        request_ScenarioData.scenarioName = UTILS.BytesToString(packetData.dataBytes, stringLen, ref parsCnt);
        #endregion

        return request_ScenarioData;
    }
}

[Serializable]
public class ChangeMapMove
{
    public PacketID packetID = PacketID.ChangeMapMove;
    public int direction;

    public ChangeMapMove() { }

    public ChangeMapMove(int _direction)
    {
        Init(_direction);
    }

    public void Init(int _direction)
    {
        direction = _direction;
    }

    public byte[] Serialization() 
    { 
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] directionBytes = BitConverter.GetBytes(direction);

        ushort len = (ushort)(directionBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, directionBytes);

        return result;
    }

    public static ChangeMapMove DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        ChangeMapMove changeMapMove = new ChangeMapMove();
        if (packetData.packetID != PacketID.ChangeMapMove) return null;

        #region direction
        changeMapMove.direction = UTILS.BytesToInt(packetData.dataBytes, ref parsCnt);
        #endregion

        return changeMapMove;
    }
}

[Serializable]
public class ChangeMapScale
{
    public PacketID packetID = PacketID.ChangeMapScale;
    public float value;

    public ChangeMapScale() { }

    public ChangeMapScale(float _value)
    {
        Init(_value);
    }

    public void Init(float _value) 
    {
        value = _value;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] valueBytes = BitConverter.GetBytes(value);

        ushort len = (ushort)(valueBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, valueBytes);

        return result;
    }

    public static ChangeMapScale DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        ChangeMapScale changeMapScale = new ChangeMapScale();
        if (packetData.packetID != PacketID.ChangeMapScale) return null;

        #region value
        changeMapScale.value = UTILS.BytesToFloat(packetData.dataBytes, ref parsCnt);
        #endregion

        return changeMapScale;
    }
}

[Serializable]
public class ChangeMapRotate
{
    public PacketID packetID = PacketID.ChangeMapRoate;
    public float value;

    public ChangeMapRotate() { }

    public ChangeMapRotate(float _value)
    {
        Init(_value);
    }

    public void Init(float _value)
    {
        value = _value;
    }

    public byte[] Serialization()
    {
        byte[] packetIDBytes = BitConverter.GetBytes((ushort)packetID);
        byte[] valueBytes = BitConverter.GetBytes(value);

        ushort len = (ushort)(valueBytes.Length);
        byte[] lengthBytes = BitConverter.GetBytes(len);

        byte[] result = UTILS.AddBytes(lengthBytes, packetIDBytes);
        result = UTILS.AddBytes(result, valueBytes);

        return result;
    }

    public static ChangeMapRotate DeSerialization(PacketData packetData)
    {
        int parsCnt = 0;
        ChangeMapRotate changeMapRotate = new ChangeMapRotate();
        if (packetData.packetID != PacketID.ChangeMapRoate) return null;

        #region value
        changeMapRotate.value = UTILS.BytesToFloat(packetData.dataBytes, ref parsCnt);
        #endregion

        return changeMapRotate;
    }
}