using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ClientManager : MonoBehaviour
{
    private static ClientManager instance;
    public static ClientManager Instance => instance;

    public TMP_Text TerrainLatIndex;
    public TMP_Text TerrainLonIndex;
    public TMP_Text TextureLatIndex;
    public TMP_Text TextureLonIndex;
    public TMP_InputField ZoomLevel;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    public void TestClient(S_MyPlayerID myPlayerID)
    {
        Debug.Log($"S_MyPlayerID : {myPlayerID.packetID}");
        Debug.Log($"S_MyPlayerID : {myPlayerID.playerID}");
    }

    public void TestClient(S_ChangeObjInfo changeObjInfo)
    {
        Debug.Log($"S_ChangeObjInfo : {changeObjInfo.packetID}");
        Debug.Log($"S_ChangeObjInfo : {changeObjInfo.playerID}");
        Debug.Log($"S_ChangeObjInfo : {changeObjInfo.interactionType}");
        Debug.Log($"S_ChangeObjInfo : {changeObjInfo.objSequence}");
        changeObjInfo.objectData.TestDebug();
    }

    public void TestClient(C_ChangeObjInfo changeObjInfo)
    {
        Debug.Log($"C_ChangeObjInfo : {changeObjInfo.packetID}");
        Debug.Log($"C_ChangeObjInfo : {changeObjInfo.playerID}");
        Debug.Log($"C_ChangeObjInfo : {changeObjInfo.interactionType}");
        Debug.Log($"C_ChangeObjInfo : {changeObjInfo.objSequence}");
        changeObjInfo.objectData.TestDebug();
    }

    public void TestClient(C_SaveScenario saveScenario)
    {
        Debug.Log($"C_SaveScenario : {saveScenario.packetID}");
        Debug.Log($"C_SaveScenario : {saveScenario.playerID}");
        Debug.Log($"C_SaveScenario : {saveScenario.scenarioName}");
        Debug.Log($"C_SaveScenario : {saveScenario.scenarioID}");
        Debug.Log($"C_SaveScenario : {saveScenario.folderName}");
        Debug.Log($"C_SaveScenario : {saveScenario.lat}");
        Debug.Log($"C_SaveScenario : {saveScenario.lon}");
        Debug.Log($"C_SaveScenario : {saveScenario.writer}");
        Debug.Log($"C_SaveScenario : {saveScenario.mapType}");
        Debug.Log($"C_SaveScenario : {saveScenario.scale}");
        Debug.Log($"C_SaveScenario : {saveScenario.range}");
        Debug.Log($"C_SaveScenario : {saveScenario.description}");
        Debug.Log($"C_SaveScenario : {saveScenario.writeDay}");
    }

    public void TestClient(S_SaveScenarioResult saveScenarioResult)
    {
        Debug.Log($"S_SaveScenarioResult : {saveScenarioResult.packetID}");
        Debug.Log($"S_SaveScenarioResult : {saveScenarioResult.playerID}");
        Debug.Log($"S_SaveScenarioResult : {saveScenarioResult.saveResult}");
    }

    public void TestClient(C_LeaveGame leaveGame)
    {
        Debug.Log($"C_LeaveGame : {leaveGame.packetID}");
        Debug.Log($"C_LeaveGame : {leaveGame.playerID}");

    }

    public void TestClient(S_BroadcastNewOwner broadcastNewOwner)
    {
        Debug.Log($"S_BroadcastNewOwner : {broadcastNewOwner.packetID}");
        Debug.Log($"S_BroadcastNewOwner : {broadcastNewOwner.playerID}");
    }
    
    public void TestSend(S_MyPlayerID data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(S_ChangeObjInfo data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(C_ChangeObjInfo data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(C_SaveScenario data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(S_SaveScenarioResult data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(C_LeaveGame data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(S_BroadcastNewOwner data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void TestSend(Request_ScenarioData data)
    {
        TcpSocketManager.Instance.Send(data.Serialization());
    }

    public void Send(int id)
    {
        OnSendButtonClick((PacketID)id);
    }

    public void OnSendButtonClick(PacketID packetID)
    {
        if (packetID == PacketID.S_MyPlayerID)
        {
            S_MyPlayerID data = new S_MyPlayerID(0);
            TestSend(data);
        }
        else if (packetID == PacketID.S_ChangeObjInfo)
        {
            ObjectData objData = Create_TestObjData();

            S_ChangeObjInfo data = new S_ChangeObjInfo(0, ScenarioObjectInteractionType.Add, 0, objData);

            TestSend(data);
        }
        else if (packetID == PacketID.C_ChangeObjInfo)
        {
            ObjectData objData = Create_TestObjData();

            C_ChangeObjInfo data = new C_ChangeObjInfo(0, ScenarioObjectInteractionType.Add, 0, objData);

            TestSend(data);
        }
        else if (packetID == PacketID.C_SaveScenario)
        {
            C_SaveScenario data = new C_SaveScenario(0, "TestID_001", "TestName_001", "TestFolder_001", 37.9998f, 125.87484f, "�Ǳ�ȯ", "3D", 1, 2, "�̰� �����ϰ��̴�.", "20230809");
            TestSend(data);
        }
        else if (packetID == PacketID.S_SaveScenarioResult)
        {
            S_SaveScenarioResult data = new S_SaveScenarioResult(0, true);
            TestSend(data);
        }
        else if (packetID == PacketID.C_LeaveGame)
        {
            C_LeaveGame data = new C_LeaveGame(0);
            TestSend(data);
        }
        else if (packetID == PacketID.S_BroadcastNewOwner)
        {
            S_BroadcastNewOwner data = new S_BroadcastNewOwner(0);
            TestSend(data);
        }
        else if(packetID == PacketID.Request_ScenarioList)
        {
            ScenarioInfoClass.Instance.LoadScenarioList();
            ScenarioInfoClass.Instance.scenarioList = ScenarioInfoClass.Instance.scenarioLists[0];
            StartCoroutine(ScenarioInfoClass.Instance.LoadScenarioData(ScenarioInfoClass.Instance.scenarioList.scenarioName));
        
            Response_ScenarioList r1 = new Response_ScenarioList(ScenarioInfoClass.Instance.scenarioList);
            byte[] result = r1.Serialization();

            PacketData packetData = PacketData.DeSerialization(result);

            Response_ScenarioList r2 = Response_ScenarioList.DeSerialization(packetData);

        }
        else if(packetID == PacketID.Request_ScenarioData)
        {
            Request_ScenarioData data = new Request_ScenarioData("scen_example_num_one");
            TestSend(data);
        }
    }

    public ObjectData Create_TestObjData()
    {
        ObjectData objData = new ObjectData();
        objData.SetObjectID(0);
        objData.SetForceSize(0);
        objData.SetForceCode("��");
        objData.SetUnitName("�׽�Ʈ�̸� 001");
        objData.SetUnitCode("�׽�Ʈ�ڵ� 001");
        objData.SetIsAlly(true);
        objData.SetUnitLat(37.9998f);
        objData.SetUnitLon(125.87484f);
        objData.SetUnitHeiget(2000);
        objData.SetShowForceMark(false);
        objData.SetUnitMission("�׽�Ʈ�ڵ�002");
        objData.SetMovingDirection(186);

        return objData;
    }
}
