using BNG;
using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class TcpSocketManager__ : MonoBehaviour
{
    private static TcpSocketManager__ instance;
    public static TcpSocketManager__ Instance => instance;

    private Socket m_Client;

    public string ip;
    public int port;

    private IPEndPoint m_ServerIpEndPoint;
    private EndPoint m_RemoteEndPoint;

    public Postbox sendPostBox;
    private Postbox receivePostbox;

    public bool isTest;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this);
        }
        else
        {
            Destroy(gameObject);
        }

        sendPostBox = new Postbox();
        receivePostbox = new Postbox();

        if (isTest)
        {
            ip = GameManager.Instance.defaultData.cloudIP;
            port = GameManager.Instance.defaultData.cloudPort;
        }
        else
        {
            if (GameManager.Instance.isCloud)
            {
                ip = GameManager.Instance.defaultData.cloudIP;
                port = GameManager.Instance.defaultData.cloudPort;
            }
            else
            {
                ip = GameManager.Instance.defaultData.photonIP;
                port = GameManager.Instance.defaultData.photonPort;
            }
        }
    }

    private void Start()
    {
        m_ServerIpEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
        m_Client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        try
        {
            m_Client.Connect(m_ServerIpEndPoint);
        }
        catch (Exception e)
        {
            Debug.LogError($"[Critical Error NetworkManager] Not Tcp Server Connected - {e}");
            //continue;
        }
        StartCoroutine(SendQueue());
        StartCoroutine(ReceiveQueue());

        //Initialize();
    }

    private void Initialize()
    {
        StartCoroutine(ServerStart());
    }

    private IEnumerator ServerStart()
    {
        while (m_Client == null || !m_Client.Connected)
        {
            m_ServerIpEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
            m_Client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            try
            {

                m_Client.Connect(m_ServerIpEndPoint);
            }
            catch (Exception e)
            {
                Debug.LogError($"[Critical Error NetworkManager] Not Tcp Server Connected - {e}");
                continue;
            }

            yield return new WaitForSeconds(1.0f);
        }

        StartCoroutine(SendQueue());
        StartCoroutine(ReceiveQueue());
    }

    private void Update()
    {
        Receive();
    }

    private void OnDisable()
    {
        OnClose();
    }

    public void OnClose()
    {
        if (m_Client != null || m_Client.Connected)
        {
            m_Client.Close();
            m_Client = null;
        }
    }

    public void Send(byte[] data)
    {
        sendPostBox.PushData(data);
    }

    private void Receive()
    {
        int receive = 0;
        if (m_Client != null && m_Client.Available != 0)
        {
            byte[] data = new byte[1024];
            try
            {
                receive = m_Client.Receive(data);
            }

            catch (SocketException ex)
            {
                Debug.Log(ex);
                return;
            }
            if (receive > 0)
            {
                receivePostbox.PushData(data);
            }
        }

    }

    private IEnumerator SendQueue()
    {
        while (true)
        {
            yield return new WaitForSeconds(0.1f);
            
            if(m_Client != null && m_Client.Connected)
            {
                try
                {
                    byte[] data = sendPostBox.GetData();
                    if (data == null) continue;

                    m_Client.Send(data, 0, data.Length, SocketFlags.None);
                }
                catch
                {
                    continue;
                }
            }           
        }
    }

    private IEnumerator ReceiveQueue()
    {
        while (true)
        {
            yield return new WaitForSeconds(0.1f);

            byte[] data = receivePostbox.GetData();

            if (data == null) continue;

            if (!doProcess(data)) continue;
        }
    }

    #region ��Ŷ ó��
    private bool doProcess(byte[] bytes)
    {
        PacketData packetData = PacketData.DeSerialization(bytes);

        if (packetData.packetID == PacketID.S_MyPlayerID)
        {
            return Processing_S_MyPlayerID(packetData);
        }
        else if (packetData.packetID == PacketID.C_ChangeObjInfo)
        {

        }
        else if (packetData.packetID == PacketID.S_ChangeObjInfo)
        {
            return Processing_S_ChangeObjInfo(packetData);
        }
        else if (packetData.packetID == PacketID.C_SaveScenario)
        {

        }
        else if (packetData.packetID == PacketID.S_SaveScenarioResult)
        {
            return Processing_S_SaveScenarioResult(packetData);
        }
        else if (packetData.packetID == PacketID.C_LeaveGame)
        {

        }
        else if (packetData.packetID == PacketID.S_BroadcastNewOwner)
        {
            return Processing_S_BroadcastNewOwner(packetData);
        }
        else if (packetData.packetID == PacketID.Response_ScenrioData)
        {
            return Processing_Response_SecnarioData(packetData);
        }
        else if (packetData.packetID == PacketID.Request_ScenarioData)
        {
            return Processing_Request_ScenarioData(packetData);
        }

        return true;
    }

    private bool Processing_S_MyPlayerID(PacketData packetData)
    {
        S_MyPlayerID s_MyPlayerID = S_MyPlayerID.DeSerialization(packetData);
        if (s_MyPlayerID == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        Debug.Log($"s_MyPlayerID");
        Debug.Log($"Player ID : {s_MyPlayerID.playerID}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");

        ScenarioInfoClass.Instance.playerID = s_MyPlayerID.playerID;

        return true;
    }

    private bool Processing_S_ChangeObjInfo(PacketData packetData)
    {
        S_ChangeObjInfo s_ChangeObjInfo = S_ChangeObjInfo.DeSerialization(packetData);
        if (s_ChangeObjInfo == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        //public int objectID;          // ������Ʈ ID
        //public int forceSize;           // �δ� �Ը�
        //public string forceCode;        // ���� ��ȣ �ڵ�
        //public string unitName;         // �δ��
        //public string unitCode;         // �δ� ����
        //public bool isAlly;             // ��/�� ����
        //public float unitLat;          // �δ� ����
        //public float unitLon;          // �δ� �浵
        //public float height;            // �δ� ����
        //public bool showForceMark;      // ���� ��ȣ ���� ����
        //public string mission;          // �ӹ�����
        //public int movingDirection;     // �̵� ����

        Debug.Log($"s_ChangeObjInfo");
        Debug.Log($"objSequence : {s_ChangeObjInfo.objSequence}");
        Debug.Log($"object ID : {s_ChangeObjInfo.objectData.GetObjectID()}");
        Debug.Log($"forceSize : {s_ChangeObjInfo.objectData.GetForceSize()}");
        Debug.Log($"forceCode : {s_ChangeObjInfo.objectData.GetForceCode()}");
        Debug.Log($"unitName : {s_ChangeObjInfo.objectData.GetUnitName()}");
        Debug.Log($"unitCode : {s_ChangeObjInfo.objectData.GetUnitCode()}");
        Debug.Log($"isAlly : {s_ChangeObjInfo.objectData.GetIsAlly()}");
        Debug.Log($"unitLat : {s_ChangeObjInfo.objectData.GetUnitLat()}");
        Debug.Log($"unitLon : {s_ChangeObjInfo.objectData.GetUnitLon()}");
        Debug.Log($"height : {s_ChangeObjInfo.objectData.GetUnitHeight()}");
        Debug.Log($"showForceMark : {s_ChangeObjInfo.objectData.GetShowForceMark()}");
        Debug.Log($"misson : {s_ChangeObjInfo.objectData.GetUnitMission()}");
        Debug.Log($"movingDirection : {s_ChangeObjInfo.objectData.GetMovingDirection()}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");

        ScenarioObjectManager.Instance.SyncScenarioObject(s_ChangeObjInfo);

        return true;
    }

    private bool Processing_S_SaveScenarioResult(PacketData packetData)
    {
        S_SaveScenarioResult s_SaveScenarioResult = S_SaveScenarioResult.DeSerialization(packetData);
        if (s_SaveScenarioResult == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        Debug.Log($"S_SaveScenarioResult");
        Debug.Log($"Player ID : {s_SaveScenarioResult.saveResult}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");
        return true;
    }

    private bool Processing_S_BroadcastNewOwner(PacketData packetData)
    {
        S_BroadcastNewOwner s_BroadcastNewOwner = S_BroadcastNewOwner.DeSerialization(packetData);
        if (s_BroadcastNewOwner == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        Debug.Log($"S_BroadcastNewOwner");
        Debug.Log($"Player ID : {s_BroadcastNewOwner.playerID}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");

        return true;
    }

    private bool Processing_Response_SecnarioData(PacketData packetData)
    {
        Response_ScenarioData response_ScenarioData = Response_ScenarioData.DeSerialization(packetData);
        if (response_ScenarioData == null) return false;

        DataSyncManager.Instance.Save_ScenarioData(response_ScenarioData.scenarioData);

        return true;
    }

    private bool Processing_Request_ScenarioData(PacketData packetData)
    {
        Request_ScenarioData request_ScenarioData = Request_ScenarioData.DeSerialization(packetData);
        if (request_ScenarioData == null) return false;

        if (ScenarioInfoClass.Instance != null)
        {
            DataSyncManager.Instance.Save_ScenarioData(ScenarioInfoClass.Instance.scenarioData);
        }
        ScenarioData scenarioData = JsonManager.ScenarioDataJsonLoad(request_ScenarioData.scenarioName);
        Response_ScenarioData response_ScenarioData = new Response_ScenarioData(scenarioData);
        Send(response_ScenarioData.Serialization());

        return true;
    }
    #endregion
}
