using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using UnityEngine;

public class TcpClientTest : MonoBehaviour
{
    public string ip;
    public int port;
    TcpClient tcpClient;
    IPEndPoint ipEndPoint;

    // Start is called before the first frame update
    void Start()
    {
        //ipEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
        tcpClient = new TcpClient(ip,port);
        tcpClient.Connect(ipEndPoint);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
