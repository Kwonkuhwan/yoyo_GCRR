using BNG;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

public class TcpSocketManager : MonoBehaviour
{
    private static TcpSocketManager instance;
    public static TcpSocketManager Instance => instance;

    private Socket m_Server, m_Client;
    private TcpClient tcpClient;

    public string ip;
    public int port;

    private IPEndPoint ipEndPoint;

    private Postbox sendPostBox;
    private Postbox receivePostbox;

    public Thread th_TcpInit, th_SendQueue, th_ReceiveQueue;

    public bool isTest;
    public bool isServerTest;

    private void Initialize()
    {
        if (GameManager.Instance.SelectMode == SelectScenrioMode.Location) 
        {
            OnClose();
            return; 
        }

        if (!isTest)
        {
            if (GameManager.Instance.isCloud)
            {
                ip = GameManager.Instance.defaultData.cloudIP;
                port = GameManager.Instance.defaultData.cloudPort;
            }
            else
            {
                ip = GameManager.Instance.defaultData.photonIP;
                port = GameManager.Instance.defaultData.photonPort;
            }

            if (GameManager.Instance.isCloud || !GameManager.Instance.isServer)
            {
                Init_Client();
            }
            else
            {
                Init_Server();
            }
        }
        else
        {
            if (isServerTest)
            {
                ip = "127.0.0.1";
                port = 9999;
            }

            if (isServerTest)
            {
                Init_Server();
            }
            else
            {
                Init_Client();
            }
        }

        th_SendQueue.Start();
        th_ReceiveQueue.Start();
    }

    private void Init_Client()
    {
        ipEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
        m_Client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        //tcpClient = new TcpClient(ipEndPoint);
        try
        {
            Debug.Log($"{ipEndPoint.Address} ���� �õ���..");

            m_Client.Connect(ipEndPoint);
        }
        catch (Exception e)
        {
            Debug.LogError($"[Critical Error NetworkManager] Not Tcp Server Connected - {e}");
            //continue;
        }
    }

    private void Init_Server()
    {
        ipEndPoint = new IPEndPoint(IPAddress.Any, port);
        m_Server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        Bind_Server();

        Debug.Log(m_Client.AddressFamily.ToString());
    }

    private void Bind_Server()
    {
        while (m_Client == null)
        {
            Task.Delay(100);

            if (m_Server == null) continue;

            m_Server.Bind(ipEndPoint);
            m_Server.Listen(10);

            m_Client = m_Server.Accept();
        }
    }

    private void Update()
    {
        Receive();
    }

    private void OnEnable()
    {
        th_TcpInit = new Thread(() => Initialize());
        th_SendQueue = new Thread(() => SendQueue());
        th_ReceiveQueue = new Thread(() => ReceiveQueue());

        th_TcpInit.IsBackground = true;
        th_SendQueue.IsBackground = true;
        th_ReceiveQueue.IsBackground = true;

        sendPostBox = new Postbox();
        receivePostbox = new Postbox();        
    }


    private void OnDisable()
    {
        OnClose();
    }

    public void OnClose()
    {
        if (th_TcpInit != null)
        {
            th_TcpInit.Abort();
            th_TcpInit = null;
        }

        if (th_ReceiveQueue != null)
        {
            th_ReceiveQueue.Abort();
            th_ReceiveQueue = null;
        }

        if (th_SendQueue != null)
        {
            th_SendQueue.Abort();
            th_SendQueue = null;
        }

        if (m_Server != null)
        {
            m_Server.Close();
            m_Server = null;
        }

        if (m_Client != null)
        {
            if (m_Client.Connected)
            {
                m_Client.Close();
                m_Client.Dispose();
            }
            m_Client = null;
        }
    }

    public void Send(byte[] data)
    {
        sendPostBox.PushData(data);
    }

    private void Receive()
    {
        int receive = 0;
        if (m_Client != null && m_Client.Available != 0)
        {
            byte[] data = new byte[m_Client.SendBufferSize];
            try
            {
                receive = m_Client.Receive(data);
            }

            catch (SocketException ex)
            {
                Debug.Log(ex);
                return;
            }
            if (receive > 0)
            {
                receivePostbox.PushData(data);
            }
        }
    }

    private void SendQueue()
    {
        while (true)
        {
            Task.Delay(10);

            if (m_Client != null && m_Client.Connected)
            {
                try
                {
                    byte[] data = sendPostBox.GetData();
                    if (data == null) continue;

                    m_Client.Send(data, 0, data.Length, SocketFlags.None);
                }
                catch
                {
                    continue;
                }
            }
        }
    }

    private void ReceiveQueue()
    {
        while (true)
        {
            Task.Delay(10);

            //yield return new WaitForSeconds(0.1f);

            byte[] data = receivePostbox.GetData();

            if (data == null) continue;

            if (!doProcess(data)) continue;
        }
    }

    #region ��Ŷ ó��
    private bool doProcess(byte[] bytes)
    {
        PacketData packetData = PacketData.DeSerialization(bytes);

        if (packetData.packetID == PacketID.S_MyPlayerID)
        {
            return Processing_S_MyPlayerID(packetData);
        }
        else if (packetData.packetID == PacketID.S_ChangeObjInfo)
        {
            return Processing_S_ChangeObjInfo(packetData);
        }
        else if (packetData.packetID == PacketID.S_SaveScenarioResult)
        {
            return Processing_S_SaveScenarioResult(packetData);
        }
        else if (packetData.packetID == PacketID.S_BroadcastNewOwner)
        {
            return Processing_S_BroadcastNewOwner(packetData);
        }
        else if (packetData.packetID == PacketID.Response_ScenrioList)
        {
            Processing_Response_ScenarioLists(packetData);
        }
        else if (packetData.packetID == PacketID.Request_ScenarioList)
        {
            Processing_Request_ScenarioLists(packetData);
        }
        else if (packetData.packetID == PacketID.Response_ScenrioData)
        {
            return Processing_Response_SecnarioData(packetData);
        }
        else if (packetData.packetID == PacketID.Request_ScenarioData)
        {
            return Processing_Request_ScenarioData(packetData);
        }
        else if(packetData.packetID == PacketID.ChangeMapMove)
        {
            return Processing_ChangeMapMove(packetData);
        }
        else if(packetData.packetID == PacketID.ChangeMapScale)
        {
            return Processing_ChangeMapScale(packetData);
        }
        else if(packetData.packetID == PacketID.ChangeMapRoate)
        {
            return Processing_ChangeMapRotate(packetData);
        }

        return true;
    }

    private bool Processing_S_MyPlayerID(PacketData packetData)
    {
        S_MyPlayerID s_MyPlayerID = S_MyPlayerID.DeSerialization(packetData);
        if (s_MyPlayerID == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        Debug.Log($"s_MyPlayerID");
        Debug.Log($"Player ID : {s_MyPlayerID.playerID}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");

        ScenarioInfoClass.Instance.playerID = s_MyPlayerID.playerID;

        return true;
    }

    private bool Processing_S_ChangeObjInfo(PacketData packetData)
    {
        S_ChangeObjInfo s_ChangeObjInfo = S_ChangeObjInfo.DeSerialization(packetData);
        if (s_ChangeObjInfo == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        //public int objectID;          // ������Ʈ ID
        //public int forceSize;           // �δ� �Ը�
        //public string forceCode;        // ���� ��ȣ �ڵ�
        //public string unitName;         // �δ��
        //public string unitCode;         // �δ� ����
        //public bool isAlly;             // ��/�� ����
        //public float unitLat;          // �δ� ����
        //public float unitLon;          // �δ� �浵
        //public float height;            // �δ� ����
        //public bool showForceMark;      // ���� ��ȣ ���� ����
        //public string mission;          // �ӹ�����
        //public int movingDirection;     // �̵� ����

        Debug.Log($"s_ChangeObjInfo");
        Debug.Log($"objSequence : {s_ChangeObjInfo.objSequence}");
        Debug.Log($"object ID : {s_ChangeObjInfo.objectData.GetObjectID()}");
        Debug.Log($"forceSize : {s_ChangeObjInfo.objectData.GetForceSize()}");
        Debug.Log($"forceCode : {s_ChangeObjInfo.objectData.GetForceCode()}");
        Debug.Log($"unitName : {s_ChangeObjInfo.objectData.GetUnitName()}");
        Debug.Log($"unitCode : {s_ChangeObjInfo.objectData.GetUnitCode()}");
        Debug.Log($"isAlly : {s_ChangeObjInfo.objectData.GetIsAlly()}");
        Debug.Log($"unitLat : {s_ChangeObjInfo.objectData.GetUnitLat()}");
        Debug.Log($"unitLon : {s_ChangeObjInfo.objectData.GetUnitLon()}");
        Debug.Log($"height : {s_ChangeObjInfo.objectData.GetUnitHeight()}");
        Debug.Log($"showForceMark : {s_ChangeObjInfo.objectData.GetShowForceMark()}");
        Debug.Log($"misson : {s_ChangeObjInfo.objectData.GetUnitMission()}");
        Debug.Log($"movingDirection : {s_ChangeObjInfo.objectData.GetMovingDirection()}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");


        ScenarioObjectManager.Instance.s_ChangeObjsQueue.Enqueue(s_ChangeObjInfo);
        //ScenarioObjectManager.Instance.syncScenarioObjectDelegate(s_ChangeObjInfo);

        return true;
    }

    private bool Processing_S_SaveScenarioResult(PacketData packetData)
    {
        S_SaveScenarioResult s_SaveScenarioResult = S_SaveScenarioResult.DeSerialization(packetData);
        if (s_SaveScenarioResult == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        Debug.Log($"S_SaveScenarioResult");
        Debug.Log($"Player ID : {s_SaveScenarioResult.saveResult}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");
        return true;
    }

    private bool Processing_S_BroadcastNewOwner(PacketData packetData)
    {
        S_BroadcastNewOwner s_BroadcastNewOwner = S_BroadcastNewOwner.DeSerialization(packetData);
        if (s_BroadcastNewOwner == null) return false;

        Debug.Log($"-------------------------------------------------------------------------------------------------");
        Debug.Log($"S_BroadcastNewOwner");
        Debug.Log($"Player ID : {s_BroadcastNewOwner.playerID}");
        Debug.Log($"-------------------------------------------------------------------------------------------------\n");

        return true;
    }

    private bool Processing_Response_ScenarioLists(PacketData packetData)
    {
        Response_ScenarioList response_ScenarioLists = Response_ScenarioList.DeSerialization(packetData);
        if (response_ScenarioLists == null) return false;

        Debug.Log($"Respones ScenarioLists");

        ScenarioInfoClass.Instance.scenarioLists.Add(response_ScenarioLists.scenarioList);

        return true;
    }

    private bool Processing_Request_ScenarioLists(PacketData packetData)
    {
        Request_ScenarioList request_ScenarioLists = Request_ScenarioList.DeSerialization(packetData);
        if (request_ScenarioLists == null) return false;

        Debug.Log($"Request ScenarioLists");

        Response_ScenarioList response_ScenarioList = new Response_ScenarioList(ScenarioInfoClass.Instance.scenarioList);
        Send(response_ScenarioList.Serialization());

        return true;
    }

    private bool Processing_Response_SecnarioData(PacketData packetData)
    {
        Response_ScenarioData response_ScenarioData = Response_ScenarioData.DeSerialization(packetData);
        if (response_ScenarioData == null) return false;

        Debug.Log($"Respones ScenarioData : {response_ScenarioData.scenarioData.scenarioName}");

        ScenarioInfoClass.Instance.scenarioData = response_ScenarioData.scenarioData;

        return true;
    }

    private bool Processing_Request_ScenarioData(PacketData packetData)
    {
        Request_ScenarioData request_ScenarioData = Request_ScenarioData.DeSerialization(packetData);
        if (request_ScenarioData == null) return false;

        Debug.Log($"Request ScenarioData : {request_ScenarioData.scenarioName}");

        ScenarioData scenarioData = JsonManager.ScenarioDataJsonLoad(request_ScenarioData.scenarioName);
        Response_ScenarioData response_ScenarioData = new Response_ScenarioData(ScenarioInfoClass.Instance.scenarioData);
        Send(response_ScenarioData.Serialization());

        return true;
    }

    private bool Processing_ChangeMapMove(PacketData packetData)
    {
        ChangeMapMove changeMapMove = ChangeMapMove.DeSerialization(packetData);
        if(changeMapMove == null) return false;

        Debug.Log($"ChangeMapMove : {changeMapMove.direction}");

        QuntizedControlClass.Instance.moveQueue.Enqueue((QuntizedDirection)changeMapMove.direction);
        //QuntizedControlClass.Instance.moveQuntized((QuntizedDirection)changeMapMove.direction, false);
        //QuntizedControlClass.Instance.Move_Quntized((QuntizedDirection)changeMapMove.direction, false);
        return true;
    }

    private bool Processing_ChangeMapScale(PacketData packetData)
    {
        ChangeMapScale changeMapScale = ChangeMapScale.DeSerialization(packetData);
        if(changeMapScale == null) return false;

        Debug.Log($"ChangeMapScale {changeMapScale.value}");

        QuntizedControlClass.Instance.scaleQueue.Enqueue(changeMapScale.value);
        //QuntizedControlClass.Instance.scaleQuntized(changeMapScale.value, false);
        //QuntizedControlClass.Instance.Scale_Quntized(changeMapScale.value, false);
        return true;
    }

    private bool Processing_ChangeMapRotate(PacketData packetData)
    {
        ChangeMapRotate changeMapRotate = ChangeMapRotate.DeSerialization(packetData);
        if(changeMapRotate == null) return false;

        Debug.Log($"ChangeMapRotate {changeMapRotate.value}");
        
        QuntizedControlClass.Instance.rotateQueue.Enqueue(changeMapRotate.value);
        //QuntizedControlClass.Instance.rotateQuntized(changeMapRotate.value, false);
        //QuntizedControlClass.Instance.Rotation_Quntized(changeMapRotate.value, false);
        return true;
    }
    #endregion
}
