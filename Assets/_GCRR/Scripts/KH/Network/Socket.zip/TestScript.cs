using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TestScript : MonoBehaviour
{
    public TMP_InputField input_Zoom;
    public TMP_InputField input_Lat;
    public TMP_InputField input_Lon;

    public TMP_Text TerrainLatIndex;
    public TMP_Text TerrainLonIndex;
    public TMP_Text TextureLatIndex;
    public TMP_Text TextureLonIndex;

    [Space(10)]
    [SerializeField] Vector2 terrainIndex;
    [SerializeField] Vector2 textureIndex;

    public void DoneButtonClick()
    {
        int zoomLevel = int.Parse(input_Zoom.text);
        double lat = double.Parse(input_Lat.text);
        double lon = double.Parse(input_Lon.text);

        terrainIndex = UTILS.Calcul_TerrainIndex(lat, lon, zoomLevel);
        textureIndex = UTILS.Calcul_TextureIndex(lat, lon, zoomLevel);

        TerrainLatIndex.text = terrainIndex.x.ToString();
        TerrainLonIndex.text = terrainIndex.y.ToString();

        TextureLatIndex.text = textureIndex.x.ToString();
        TextureLonIndex.text = textureIndex.y.ToString();
    }
}
